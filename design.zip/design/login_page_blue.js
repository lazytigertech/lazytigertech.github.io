function openDocsSideNav(){document.getElementById("docs-side-nav").style.width="100%";document.getElementById("docs-side-nav").style.paddingLeft="24px";document.body.style.overflow="hidden";}
function closeDocsSideNav(){document.getElementById("docs-side-nav").style.width="0";document.getElementById("docs-side-nav").style.paddingLeft="0px";document.body.style.overflow="auto";}

document.getElementById("login-button-dropdown").style.display = "none";

function openLogin(){
    console.log("login");
}
